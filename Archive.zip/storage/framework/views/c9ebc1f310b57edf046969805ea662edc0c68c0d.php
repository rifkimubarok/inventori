<?php
    $number = 0;
    $total_barang= 0;
?>
<table class="table table-striped table-bordered" style="max-height:350px;">
    <thead>
        <tr>
            <th>No.</th>
            <th>Nama Barang.</th>
            <th>Jumlah.</th>
            <th width="40px">#</th>                
        </tr>
    </thead>
    <tbody>
        <?php
            $detail_transaksi = $output->detail_transaksi;
        ?>
        <?php $__currentLoopData = $detail_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $total_barang += $item->jml;
            ?>
            <tr>
                <td><?php echo e($number+=1); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e($item->jml); ?></td>
                <?php if(!isset($output->param['mode'])): ?>
                    <td><button class="btn btn-danger btn-xs btn-delete-detail" data-value=<?php echo e($item->id); ?>><i class="fas fa-trash"></i></button></td>
                <?php else: ?>
                    <?php if($item->isReturn == 0): ?>
                        <td><button class="btn btn-success btn-xs btn-return-detail" data-value=<?php echo e($item->id); ?>>Kembalikan</button></td>
                    <?php endif; ?>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="2" class="text-right">Jumlah :</td>
            <td><?php echo e(number_format($total_barang,0)); ?></td>
        </tr>
    </tfoot>
</table><?php /**PATH /Applications/AMPPS/www/invent/resources/views/dashboard/transaksi/keluar_detail.blade.php ENDPATH**/ ?>