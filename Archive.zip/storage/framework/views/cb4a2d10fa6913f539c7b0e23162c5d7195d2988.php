

<?php $__env->startSection('title'); ?>
    Tambah Data Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Tambah Data Barang</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah Data Barang</li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        <!-- /.col-md-6 -->
        <div class="col-lg-12">
            <div class="card">
            <div class="card-header">
                <h5 class="m-0">Form Data Barang</h5>
            </div>
            <div class="card-body">              
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo e(route('barang_new')); ?>" method="post">
                            <div class="row">
                                    <?php echo e(csrf_field()); ?>

                                <div class="form-group col-md-6">
                                    <label for="">Nama Barang</label>
                                    <input class="form-control <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" value="<?php echo e(old('nama_barang')); ?>" name="nama_barang" id="nama_barang">
                                    <?php if ($errors->has('nama_barang')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama_barang'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                
                                <div class="form-group col-md-3">
                                    <label for="">Jumlah</label>
                                    <input class="form-control <?php if ($errors->has('jumlah')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jumlah'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="number" value="<?php echo e(old('jumlah')); ?>" name="jumlah" id="jumlah">
                                    <?php if ($errors->has('jumlah')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jumlah'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                
                                <div class="form-group col-md-3">
                                    <label for="">Satuan</label>
                                    <input class="form-control <?php if ($errors->has('satuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('satuan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="satuan" id="satuan" value="<?php echo e(old('satuan')); ?>">
                                    <?php if ($errors->has('satuan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('satuan'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group col-md-12">
                                    <button class="btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/AMPPS/www/invent/resources/views/dashboard/barang/insert.blade.php ENDPATH**/ ?>