<?php $__env->startSection('title'); ?>
    Transaksi Barang Keluar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark">Transaksi Barang Keluar</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Daftar Transaksi</li>
            </ol>
        </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        <!-- /.col-md-6 -->
        <div class="col-lg-12">
            <div class="card">
            <div class="card-header">
                <h5 class="m-0">Daftar Transaksi</h5>
            </div>
            <div class="card-body">              
                <div class="row">
                    <div class="col-md-12 mb-3">
                    <a href="<?php echo e(route('tr_keluar_new')); ?>"><button class="btn btn-primary float-right"><i class="fas fa-plus"></i> Transaksi Baru</button></a>
                    </div>
                    <div class="col-md-12">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th width="1%">No</th>
                                    <th>Tgl Transaksi</th>
                                    <th>Jumlah Barang</th>
                                    <th>Total Harga</th>
                                    <th>#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $nomor = 0;
                                ?>
                                <?php $__currentLoopData = $barang_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e($nomor+=1); ?></td>
                                    <td><?php echo e($item->tgl_transaksi); ?></td>
                                    <td><?php echo e($item->total_barang); ?></td>
                                    <td><?php echo e(number_format($item->total_harga,0)); ?></td>
                                    <td><a href="/transaksi/keluar/detail/<?php echo e($item->id); ?>" class="btn-detail"><button class="btn btn-primary btn-xs" title="Detail Transaksi"><i class="fas fa-list"></i></button></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th width="1%">No</th>
                                    <th>Nama Barang</th>
                                    <th>Jumlah</th>
                                    <th>Harga</th>
                                    <th>#</th>
                                </tr>
                            </tfoot>
                            </table>
                            <div>
                                <?php echo e($barang_keluar->links()); ?>

                            </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</div>


<div class="modal fade" id="detail_transaksi">
        <div class="modal-dialog">
            <div class="modal-content">
            
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Detail Transaksi</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal body -->
            <div class="modal-body table-responsive">
                
            </div>
            
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
<script>
// $('table').DataTable();
$('table').on("click",".btn-detail",function(e) {
    e.preventDefault;
    var url = $(this).attr("href");
    $.ajax({
        url:url,
        dataType:"html",
        type:"get",
        success:function(result){
            $('.modal-body').html(result);
            $('#detail_transaksi').modal("show");
        }
    })
    return false;
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invent\resources\views/dashboard/transaksi/keluar.blade.php ENDPATH**/ ?>