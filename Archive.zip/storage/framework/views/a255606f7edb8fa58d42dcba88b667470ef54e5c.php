<?php
    $number = 0;
    $total_barang= 0;
    $total_harga = 0;
?>
<table class="table table-striped table-bordered" style="max-height:350px;">
    <thead>
        <tr>
            <th>No.</th>
            <th>Nama Barang.</th>
            <th>Jumlah.</th>
            <th>Harga Beli.</th>
            <th>Total Harga.</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $detail_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $total_barang += $item->jml;
                $total_harga += $item->total_harga;
            ?>
            <tr>
                <td><?php echo e($number+=1); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e($item->jml); ?></td>
                <td><?php echo e(number_format($item->harga_beli,0)); ?></td>
                <td><?php echo e(number_format($item->total_harga,0)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="2" class="text-right">Jumlah :</td>
            <td><?php echo e(number_format($total_barang,0)); ?></td>
            <td></td>
            <td><?php echo e(number_format($total_harga,0)); ?></td>
        </tr>
    </tfoot>
</table><?php /**PATH /Applications/AMPPS/www/invent/resources/views/dashboard/transaksi/masuk_detail.blade.php ENDPATH**/ ?>