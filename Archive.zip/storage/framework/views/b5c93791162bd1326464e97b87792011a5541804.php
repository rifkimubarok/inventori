<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>No.</th>
            <th>Nama Barang</th>
            <th>Jumlah</th>
            <th>Harga Jual</th>
            <th>Total Harga</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $grant_total = 0;
            $grant_total_barang = 0;
        ?>
        <?php $__currentLoopData = $data_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $grant_total += $item->total_harga;
                $grant_total_barang += $item->total_barang;
            ?>
            <tr>
            <td colspan="4"><strong><?php echo e($item->tgl_transaksi); ?></strong></td>
            <td class="text-center">Rp. <?php echo e(number_format($item->total_harga,0)); ?></td>
            </tr>
            <?php
                $nomor = 0;
            ?>
            <?php $__currentLoopData = $item->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-right"><?php echo e($nomor+=1); ?></td>
                <td><?php echo e($row->nama_barang); ?></td>
                <td><?php echo e($row->jml); ?></td>
                <td class="text-center"><?php echo e(number_format($row->harga_jual,0)); ?></td>
                <td class="text-center">Rp. <?php echo e(number_format($row->total_harga,0)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <th colspan="2" class="text-right">
            <strong>Jumlah :</strong>
        </th>
        <td><?php echo e(number_format($grant_total_barang,0)); ?></td>
        <td></td>
        <td class="text-center">Rp. <?php echo e(number_format($grant_total,0)); ?></td>
    </tfoot>
</table><?php /**PATH C:\xampp\htdocs\invent\resources\views/dashboard/laporan/table_keluar.blade.php ENDPATH**/ ?>